# bag-counting > 2026-02-28 10:13am
https://universe.roboflow.com/sarthaks-workspace-brqw9/bag-counting-zyzik

Provided by a Roboflow user
License: CC BY 4.0

